static struct pippo **pluto (void) {

}

static struct pp qq (void) {

}

static cc ss (void) {

}

static aa bb (int a,
              char *p) {

}

dd *ee (void) {

  bb(0, "pip\"po",     "pluto");
}
