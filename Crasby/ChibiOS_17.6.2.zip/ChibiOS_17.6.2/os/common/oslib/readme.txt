All the code contained under ./os/common/oslib are optional RTOS modules
compatible with both RT and NIL. The code is placed under ./os/common in
order to prevent code duplication and disalignments.
