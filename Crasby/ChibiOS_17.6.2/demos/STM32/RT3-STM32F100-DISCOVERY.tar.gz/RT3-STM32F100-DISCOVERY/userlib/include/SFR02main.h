#include "hal.h"
#include "userconf.h"

#ifndef SFR02main_H_
#define SFR02main_H_

#ifdef __cplusplus
extern "C" {
#endif
  void Sfr02Start(void);
#ifdef __cplusplus
}
#endif

#endif /* LIS3_H_ */
